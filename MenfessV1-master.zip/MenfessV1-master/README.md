# Scbot-Menfess

How to install in termux?

```

pkg upgrade && pkg update

pkg install ffmpeg -y

pkg install nodejs -y

pkg install yarn -y

pkg install git -y

git clone https://github.com/Lexxy24/MenfessV1

cd MenfessV1

yarn install

node main.js

```

scan qr code on whatsapp multi device
